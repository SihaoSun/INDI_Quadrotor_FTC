/*
 * /home/sihao/src/monorepo/simulink_model/.codeGenCache/slprj/grt/_sharedutils/mldivide_I8OBiDMa.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "URControl_att_indi_simple".
 *
 * Model version              : 1.181
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C++ source code generated on : Tue Jun 30 13:36:02 2020
 * Created for block: URControl_att_indi_simple
 */

#ifndef SHARE_mldivide_I8OBiDMa
#define SHARE_mldivide_I8OBiDMa
#include "rtwtypes.h"

extern void mldivide_I8OBiDMa(const real_T A[16], real_T B[16]);

#endif
