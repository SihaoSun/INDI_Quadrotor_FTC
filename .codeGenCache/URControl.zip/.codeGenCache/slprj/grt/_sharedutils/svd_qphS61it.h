/*
 * /home/sihao/src/monorepo/simulink_model/.codeGenCache/slprj/grt/_sharedutils/svd_qphS61it.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "URControl_att".
 *
 * Model version              : 1.32
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C++ source code generated on : Thu Dec 19 17:18:07 2019
 * Created for block: URControl_att
 */

#ifndef SHARE_svd_qphS61it
#define SHARE_svd_qphS61it
#include "rtwtypes.h"

extern void svd_qphS61it(const real_T A[16], real_T U[16], real_T s[4], real_T
  V[16]);

#endif
