/*
 * /home/sihao/src/monorepo/simulink_model/.codeGenCache/slprj/grt/_sharedutils/xgetrf_vu1x6Wed.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "URControl_att_indi_simple".
 *
 * Model version              : 1.181
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C++ source code generated on : Tue Jun 30 13:36:02 2020
 * Created for block: URControl_att_indi_simple
 */

#ifndef SHARE_xgetrf_vu1x6Wed
#define SHARE_xgetrf_vu1x6Wed
#include "rtwtypes.h"

extern void xgetrf_vu1x6Wed(real_T A[16], int32_T ipiv[4], int32_T *info);

#endif
