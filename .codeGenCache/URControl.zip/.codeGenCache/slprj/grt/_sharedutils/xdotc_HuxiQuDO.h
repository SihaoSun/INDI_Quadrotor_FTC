/*
 * /home/sihao/src/monorepo/simulink_model/.codeGenCache/slprj/grt/_sharedutils/xdotc_HuxiQuDO.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "URControl_att".
 *
 * Model version              : 1.32
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C++ source code generated on : Thu Dec 19 17:18:07 2019
 * Created for block: URControl_att
 */

#ifndef SHARE_xdotc_HuxiQuDO
#define SHARE_xdotc_HuxiQuDO
#include "rtwtypes.h"

extern real_T xdotc_HuxiQuDO(int32_T n, const real_T x[16], int32_T ix0, const
  real_T y[16], int32_T iy0);

#endif
