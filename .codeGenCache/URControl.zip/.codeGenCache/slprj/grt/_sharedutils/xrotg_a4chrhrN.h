/*
 * /home/sihao/src/monorepo/simulink_model/.codeGenCache/slprj/grt/_sharedutils/xrotg_a4chrhrN.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "URControl_att".
 *
 * Model version              : 1.32
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C++ source code generated on : Thu Dec 19 17:18:07 2019
 * Created for block: URControl_att
 */

#ifndef SHARE_xrotg_a4chrhrN
#define SHARE_xrotg_a4chrhrN
#include "rtwtypes.h"

extern void xrotg_a4chrhrN(real_T *a, real_T *b, real_T *c, real_T *s);

#endif
